<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/easy-editable-text.js"></script>


<style type="text/css">
input[type=text]
{
	margin-top:8px;
	font-size:18px;
	color:#545454;
	-moz-border-radius: 2px;
	-webkit-border-radius: 2px;
	-border-radius: 2px;
	display:none;
	width:280px;
	
}

label
{
	float:left;
	margin-top:8px;
	font-size:18px;
	color:#545454;
	-moz-border-radius: 2px;
	-webkit-border-radius: 2px;
	-border-radius: 2px;
}

.edit
{
	float:left;
	background:url(images/edit.png) no-repeat;
	width:32px;
	height:32px;
	display:block;
	cursor: pointer;
	margin-left:10px;
}

.clear
{
	clear:both;
	height:20px;
}

</style>

<title>jQuery - Easy editable text fields</title>
</head>
<body>

<label class="text_label">Click The Pencil Icon to Edit Me</label><div class="edit"></div>
<input type="text" value="Click The Pencil Icon to Edit Me" />

<div class="clear"></div>

<label class="text_label">This is another text label</label><div class="edit"></div>
<input type="text" value="This is another text label" />

<div class="clear"></div>

<label class="text_label">Another text label</label><div class="edit"></div>
<input type="text" value="Another text label" />

<div class="clear"></div>

<label class="text_label">This is the last text label</label><div class="edit"></div>
<input type="text" value="This is the last text label" />

<div class="clear"></div>

<?php include('../468x60ad.html'); ?>
<?php include('../analytics.html'); ?>

</body>
</html>

# Simple youtube clone written in react

This is a simple video app that uses the youtube api to fetch videos.

You can type a video in the search bar and search for videos.


**Screenshot**
![alt text](https://raw.githubusercontent.com/lkuoch/react-yt/master/public/Example.png "Example screenshot")

**Running**
To run simply clone the repository and run the command
```
npm start
```

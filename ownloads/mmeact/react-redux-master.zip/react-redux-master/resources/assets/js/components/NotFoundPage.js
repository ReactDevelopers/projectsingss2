import React from 'react';

const NotFoundPage = () => (
    <div className={"loading-div"}>
        <img src={"/images/notfound.jpg"} className={"loading-circular-progress"} />
    </div>
);

export default NotFoundPage;
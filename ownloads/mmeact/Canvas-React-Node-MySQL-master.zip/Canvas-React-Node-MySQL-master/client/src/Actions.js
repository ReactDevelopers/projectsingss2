export function changeSearchData(data){
  return{
    type: "CHANGE_SEARCH_DATA",
    data
  }
}

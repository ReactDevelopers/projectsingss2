import React, { Component } from 'react'

class NoMatch extends Component {

  render() {
    return (
      <div>Oops, are you lost???</div>
    )
  }

}

export default NoMatch

import {connect} from 'react-redux'
import Page from './Page'

export default connect()(Page);
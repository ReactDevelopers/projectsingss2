import React from 'react'

class Page extends React.Component {
    constructor(props){
        super(props);

    }



    render() {
        return(
            <h1>Lost in space !</h1>
        );
    }
}

export default Page;
interface Task {
  completed: boolean;
  description: string;
}

export default Task;

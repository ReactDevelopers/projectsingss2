<template>
    <div class="page">
        <h1>{{msg}}  </h1>
        <!--<header></header>-->
    </div>
</template>
<script lang="ts" src="./index.ts"></script>
<style lang="scss" scoped src="./index.scss"></style>
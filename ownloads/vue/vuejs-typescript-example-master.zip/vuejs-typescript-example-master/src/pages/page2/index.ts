import Vue from 'vue';
// import Header from '../header/index.vue';



export default Vue.extend({
    data: ()=>{
          return {  msg: 'This is page 2'}
        }
});
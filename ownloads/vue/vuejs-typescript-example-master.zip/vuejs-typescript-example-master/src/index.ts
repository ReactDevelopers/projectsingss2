

require('./style/index.scss');

require('./main.ts');

import Vue from 'vue';

export default Vue.extend({
    name:'pageFooter',
    data: ()=>{
        return {  msg: 'This is Footer'}
    }
});


import Vue from 'vue';

export default Vue.extend({
    name:'pageHeader',
    data: ()=>{
        return {  msg: 'This is header'}
    }
});

export interface AppState {
    value: number
}
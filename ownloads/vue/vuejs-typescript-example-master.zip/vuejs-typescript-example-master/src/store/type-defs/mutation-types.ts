export const MutationTypes = {
    ADD_VALUE: 'ADD_VALUE',
    RESET_VALUE: 'RESET_VALUE'
};
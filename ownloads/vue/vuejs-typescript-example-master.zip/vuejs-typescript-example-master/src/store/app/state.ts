import {AppState} from "../type-defs";

export const state: AppState = {
    value: 0
};
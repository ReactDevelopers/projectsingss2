<template>
<div>{{ msg }}</div>
</template>

<script>
export default {
  data () {
    return {
      msg: 'Hello from vue'
    }
  }
}
</script>
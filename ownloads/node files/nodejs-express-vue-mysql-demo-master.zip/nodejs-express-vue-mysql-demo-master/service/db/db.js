module.exports = {
    mysql: {
        host: 'localhost',
        user: 'root',
        password: 'root',
        database:'nbver_live'
    }
}
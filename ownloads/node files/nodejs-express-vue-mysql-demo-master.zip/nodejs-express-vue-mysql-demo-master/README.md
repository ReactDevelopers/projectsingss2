# nodejs-express-vue-mysql-demo
nodejs-express-vue-mysql 整合的一个CRUDdemo
## 启动服务
```
service 目录下 执行
    node app.js
    [监听端口：3000]
```
> A Vue.js project

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

For detailed explanation on how things work, checkout the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
